//
//  Result.swift
//  Tipsy
//
//  Created by Kwangjun Kim on 2022/05/13.
//  Copyright © 2022 The App Brewery. All rights reserved.
//

import Foundation

struct Result {
    var totalLabelText: String
    var settingLabelText: String
}
